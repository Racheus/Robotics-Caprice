clear
clc
syms q1 q2 q3 q4 q5 q6
syms dq1 dq2 dq3 dq4 dq5 dq6
syms ddq1 ddq2 ddq3 ddq4 ddq5 ddq6
% syms m1 m2 m3 m4 m5 m6 g
m1 = 1;
m2 = 1;
m3 = 1;
m4 = 1;
m5 = 1;
m6 = 1;
g = 9.81;
%% 由DH参数获取旋转矩阵
R = cell(1, 7);
T01 = get_trans_from_DH(0, 0, 120, q1);
R{1} = T01(1:3, 1:3);
T12 = get_trans_from_DH(0, -pi/2, 145, q2);
R{2} = T12(1:3,1:3);
T23 = get_trans_from_DH(430, 0, 0, q3);
R{3} = T23(1:3, 1:3);
T34 = get_trans_from_DH(370, 0, -35, q4);
R{4} = T34(1:3, 1:3);
T45 = get_trans_from_DH(0, pi/2, 110, q5);
R{5} = T45(1:3, 1:3);
T56 = get_trans_from_DH(0, pi/2, 107, q6);
R{6} = T56(1:3, 1:3);
R{7}=[1 0 0;0 1 0;0 0 1];
%% 坐标系原点位移，用P{1}表示坐标系1与坐标系0原点位置关系，用P{2}表示坐标系2与坐标系1原点位置关系。
p = cell(1, 7);
p{1} = [0;0;0];
p{2} = [0;0;120];
p{3} = [0;145;0];
p{4} = [430;0;0];
p{5} = [370;0;-35];
p{6} = [0;-110;0];
p{7} = [0;-107;0];
%% 质心位置，先假设质量集中在末端点
pc = cell(1, 7);
pc{1} = [0;0;0];
pc{2} = [0;0;120];
pc{3} = [0;145;0];
pc{4} = [430;0;0];
pc{5} = [370;0;-35];
pc{6} = [0;-110;0];
pc{7} = [0;-107;0];
%% 连杆质量
m = cell(1, 7);
m{2} = m1;
m{3} = m2;
m{4} = m3;
m{5} = m4;
m{6} = m5;
m{7} = m6;
%% 惯量
I = cell(1, 7);
for i = 2:7
    I{i} = [0;0;0];
end
%% 连杆间角速度和角加速度
w = cell(1,7);dw = cell(1,7);
w{1}=[0;0;0];dw{1}=[0;0;0];% 机器人底座不旋转
% 连杆坐标原点和质心加速度
dv = cell(1,7);dvc = cell(1,7);
dv{1}=[0;0;-g];% 重力因素
%% 关节速度和加速度
dq = cell(1,7); ddq = cell(1,7); 
dq{2}=[0;0;dq1];dq{3}=[0;0;dq2];dq{4}=[0;0;dq3];dq{5}=[0;0;dq4];dq{6}=[0;0;dq5];dq{7}=[0;0;dq6];
ddq{2}=[0;0;ddq1];ddq{3}=[0;0;ddq2];ddq{4}=[0;0;ddq3];ddq{5}=[0;0;ddq4];ddq{6}=[0;0;ddq5];ddq{7}=[0;0;ddq6];
% 末端执行器没有力
f = cell(1,8);n = cell(1,8);F = cell(1,7);N = cell(1,7);
f{8}=[0;0;0];
n{8}=[0;0;0];
%% 建立运动学方程
% 外推
for i=1:6 %matlab下标从1开始
w{i+1}=R{i}.'*w{i}+dq{i+1};
dw{i+1}=R{i}.'*dw{i}+cross(R{i}.'*w{i},dq{i+1})+ddq{i+1};

dv{i+1}=R{i}.'*(cross(dw{i},p{i})+cross(w{i},cross(w{i},p{i}))+dv{i});
dvc{i+1}=cross(dw{i+1},pc{i+1})+cross(w{i+1},cross(w{i+1},pc{i+1}))+dv{i+1};

F{i+1}=m{i+1}*dvc{i+1};
N{i+1}=[0;0;0];%假设质量集中，每个连杆惯性张量为0
end
% 内推
for i=7:-1:2
    f{i}=R{i}*f{i+1}+F{i};
    n{i}=N{i}+R{i}*n{i+1}+cross(pc{i},F{i})+cross(p{i},R{i}*f{i+1});
end
% 力矩
tau = cell(1,6);
tau{1} = n{2}(3);
tau{2} = n{3}(3);
tau{3} = n{4}(3);
tau{4} = n{5}(3);
tau{5} = n{6}(3);
tau{6} = n{7}(3);
celldisp(tau)
function [Ji] = get_jacob_row(T)
n = T(1:3, 1);
o = T(1:3, 2);
a = T(1:3, 3);
p = T(1:3, 4);
e1 = cross(p, n);
e1 = e1(3, 1);
e2 = cross(p, o);
e2 = e2(3, 1);
e3 = cross(p, a);
e3 = e3(3, 1);
e4 = n(3, 1);
e5 = o(3, 1);
e6 = a(3, 1);
Ji = [e1;e2;e3;e4;e5;e6];
end

function [T] = get_trans_from_DH(a, alpha, d, theta)
T = trotx(alpha) * transl(a, 0, 0) * transl(0, 0, d) * trotz(theta);
end
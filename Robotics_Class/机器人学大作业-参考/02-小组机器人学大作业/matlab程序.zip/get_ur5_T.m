function [T] = get_ur5_T(theta1, theta2, theta3, theta4, theta5, theta6)
T01 = get_trans_from_DH(0, 0, 120, theta1);
T12 = get_trans_from_DH(0, -pi/2, 145, theta2);
T23 = get_trans_from_DH(430, 0, 0, theta3);
T34 = get_trans_from_DH(370, 0, -35, theta4);
T45 = get_trans_from_DH(0, pi/2, 110, theta5);
T56 = get_trans_from_DH(0, pi/2, 107, theta6);
T = T01 * T12 * T23 * T34 * T45 * T56;
end
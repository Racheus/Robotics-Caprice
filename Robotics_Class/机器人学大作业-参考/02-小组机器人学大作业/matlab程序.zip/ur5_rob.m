L1 = Link('a', 0, 'alpha', 0, 'd', 120, 'offset', 0, 'modified');
L2 = Link('a', 0, 'alpha', -pi/2, 'd', 145, 'offset', -pi/2, 'modified');
L3 = Link('a', 430, 'alpha', 0, 'd', 0, 'offset', 0, 'modified');
L4 = Link('a', 370, 'alpha', 0, 'd', -35, 'offset', pi/2, 'modified');
L5 = Link('a', 0, 'alpha', pi/2, 'd', 110, 'offset', 0, 'modified');
L6 = Link('a', 0, 'alpha', pi/2, 'd', 107, 'offset', 0, 'modified');
ur5 = SerialLink([L1 L2 L3 L4 L5 L6]);
ur5.teach();

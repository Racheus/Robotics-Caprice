time = (0:0.02:(size(tau, 1)-1)*0.02)';
data = [time, tau];
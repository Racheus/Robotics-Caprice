function d = distance(x,y)
%DISTANCE 此处显示有关此函数的摘要
%   此处显示详细说明
d=sqrt((x(1,1)-y(1,1))^2+(x(2,1)-y(2,1))^2+(x(3,1)-y(3,1))^2);
end

